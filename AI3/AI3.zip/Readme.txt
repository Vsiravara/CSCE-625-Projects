 -------------------------------------README-------------------------------------
 Vishwas Siravara
 623009600
 Assignment 3
 Instructions to compile code

 There are 2 files one for each problem 
 AI3.py for jobs puzzle and
 AI3b.py for Zebra Puzzle
Instructions for compiling 
Python Version - Python 2.7.6

For jobs puzzle
> python AI3.py

For zebra puzzle
> python AI3b.py

